﻿using FluentValidation;
using $projectname$.Features.$servicename$.Commands;
using $datanamespace$;
using $domainnamespace$;

namespace $rootnamespace$
{
    public class Create$servicename$Validator : AbstractValidator<Create$servicename$Command>
    {
        public Create$servicename$Validator()
        {
        }
    }
}
