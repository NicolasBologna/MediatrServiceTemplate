﻿using FluentValidation;
using $projectname$.Features.$servicename$.Commands;
using $datanamespace$;
using $domainnamespace$;

namespace $rootnamespace$
{
    public class Update$servicename$Validator : AbstractValidator<Update$servicename$Command>
    {
        public Update$servicename$Validator()
        {
        }
    }
}
