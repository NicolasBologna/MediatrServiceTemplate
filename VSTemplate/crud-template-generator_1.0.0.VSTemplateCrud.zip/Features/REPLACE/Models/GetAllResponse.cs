﻿namespace $rootnamespace$
{
    public class Get$fileinputname$sResponse
    {
    }
}
